/*********************************************************/
/*********BOSCH BEA PROGRAM SKELETON DEMO CODE************/
/*********************************************************/

#ifndef _DCM_WDBI_H
#define _DCM_WDBI_H

#include "dcm.h"


#endif
