/*********************************************************/
/*********BOSCH BEA PROGRAM SKELETON DEMO CODE************/
/*********************************************************/

#ifndef _DCM_RDBI_H
#define _DCM_RDBI_H

#include "dcm.h"

#endif
